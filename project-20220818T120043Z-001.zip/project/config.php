<?php

$conn = mysqli_connect('localhost','root','','shoponline_db') or die('connection failed');

?>